package com.geekster.DoctorsAppointmentApplication.model;

public enum Specialization {
    Allergy_and_Immunology, Anesthesiology, Dermatology, Diagnostic_Radiology,
    Emergency_Medicine, Family_Medicine, Internal_Medicine, Medical_Genetics,
    Neurology, Nuclear_Medicine, Obstetrics_and_Gynecology, Ophthalmology,
    Pathology, Pediatrics, Physical_Medicine_and_Rehabilitation, Preventive_Medicine,
    Psychiatry, Radiation_Oncology, Surgery, Urology
}